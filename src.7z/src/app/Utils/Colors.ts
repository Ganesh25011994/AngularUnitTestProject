export const Colors = [
    '#b87333',
    'silver',
    'gold',
    '#e5e4e2',
    'yellow',
    '#434343',
    '#777',
    'red',
    'blue',
    'orange'
]

